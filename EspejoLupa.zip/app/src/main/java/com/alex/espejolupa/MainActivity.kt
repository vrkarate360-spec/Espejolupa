package com.alex.espejolupa

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var frozenView: ImageView
    private lateinit var lightPanel: View
    private lateinit var cameraArea: FrameLayout
    private lateinit var touchLayer: View
    private lateinit var focusRing: View
    private lateinit var pauseTag: TextView
    private lateinit var zoomBar: SeekBar
    private lateinit var zoomText: TextView
    private lateinit var btnPause: Button
    private lateinit var btnLight: Button
    private lateinit var btnSharp: Button
    private lateinit var btnSwitch: Button

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val maxZoom = 20f          // zoom total: óptico/cámara + digital

    private var useFront = true
    private var lightOn = false
    private var lightColorIndex = 0
    private val lightColors = intArrayOf(
        Color.WHITE, Color.rgb(255, 236, 205), Color.rgb(228, 238, 255)
    )

    // Imagen en directo
    private var liveZoom = 1f          // zoom total pedido
    private var camRatio = 1f          // parte que hace la cámara
    private var extraScale = 1f        // parte digital (ampliar la vista)

    // Imagen en pausa
    private var paused = false
    private var pauseToken = 0
    private var frozenBase = 1f        // zoom de cámara cuando se pausó
    private var frozenScale = 1f       // ampliación digital sobre la foto
    private var panX = 0f
    private var panY = 0f
    private var original: Bitmap? = null
    private var sharpLevel = 0
    private val sharpAmounts = floatArrayOf(0f, 0.8f, 1.6f, 2.6f)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera()
            else Toast.makeText(this, "Hace falta permiso de cámara", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        frozenView = findViewById(R.id.frozenView)
        lightPanel = findViewById(R.id.lightPanel)
        cameraArea = findViewById(R.id.cameraArea)
        touchLayer = findViewById(R.id.touchLayer)
        focusRing = findViewById(R.id.focusRing)
        pauseTag = findViewById(R.id.pauseTag)
        zoomBar = findViewById(R.id.zoomBar)
        zoomText = findViewById(R.id.zoomText)
        btnPause = findViewById(R.id.btnPause)
        btnLight = findViewById(R.id.btnLight)
        btnSharp = findViewById(R.id.btnSharp)
        btnSwitch = findViewById(R.id.btnSwitch)

        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER

        setupZoomBar()
        setupGestures()

        btnPause.setOnClickListener { if (paused) resume() else pause() }
        btnLight.setOnClickListener { toggleLight() }
        btnSharp.setOnClickListener { cycleSharpness() }
        btnSwitch.setOnClickListener {
            if (paused) resume()
            useFront = !useFront
            liveZoom = 1f
            bindCamera()
        }
        lightPanel.setOnClickListener {
            lightColorIndex = (lightColorIndex + 1) % lightColors.size
            lightPanel.setBackgroundColor(lightColors[lightColorIndex])
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permLauncher.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }

    // ---------- Cámara ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        var selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                       else CameraSelector.DEFAULT_BACK_CAMERA
        if (!provider.hasCamera(selector)) {
            useFront = !useFront
            selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                       else CameraSelector.DEFAULT_BACK_CAMERA
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()
        try {
            camera = provider.bindToLifecycle(this, selector, preview, imageCapture)
            val wanted = liveZoom
            camera?.cameraInfo?.zoomState?.observe(this) { z ->
                // Cuando la cámara está lista, aplicamos el zoom pedido una vez
                if (z != null) {
                    camera?.cameraInfo?.zoomState?.removeObservers(this)
                    setLiveZoom(wanted)
                }
            }
            setLiveZoom(wanted)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir la cámara", Toast.LENGTH_LONG).show()
        }
    }

    /** Reparte el zoom total entre la cámara (máxima calidad) y ampliación digital. */
    private fun setLiveZoom(z: Float) {
        liveZoom = z.coerceIn(1f, maxZoom)
        val st = camera?.cameraInfo?.zoomState?.value
        val camMax = st?.maxZoomRatio ?: 1f
        val camMin = max(1f, st?.minZoomRatio ?: 1f)
        camRatio = liveZoom.coerceIn(camMin, max(camMin, camMax))
        camera?.cameraControl?.setZoomRatio(camRatio)
        extraScale = liveZoom / camRatio
        previewView.scaleX = extraScale
        previewView.scaleY = extraScale
        updateZoomUi(liveZoom)
    }

    // ---------- Zoom (barra y pellizco) ----------

    private fun zoomToProgress(z: Float) = (ln(z) / ln(maxZoom) * 100).roundToInt()
    private fun progressToZoom(p: Int) = maxZoom.pow(p / 100f)

    private fun updateZoomUi(total: Float) {
        zoomText.text = if (total < 10f) String.format("%.1fx", total)
                        else "${total.roundToInt()}x"
        zoomBar.progress = zoomToProgress(total)
    }

    private fun setupZoomBar() {
        zoomBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val z = progressToZoom(progress)
                if (paused) setFrozenTotal(z) else setLiveZoom(z)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: ScaleGestureDetector): Boolean {
                    if (paused) setFrozenTotal(frozenBase * frozenScale * d.scaleFactor)
                    else setLiveZoom(liveZoom * d.scaleFactor)
                    return true
                }
            })
        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (!paused) focusAt(e.x, e.y)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (paused && !scaleDetector.isInProgress) {
                    panX -= dx; panY -= dy
                    applyFrozen()
                }
                return true
            }
        })
        touchLayer.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(ev)
            true
        }
    }

    // ---------- Enfoque (tocar la pantalla) ----------

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        // Pasar el punto tocado a coordenadas de la vista sin la ampliación digital
        val cx = previewView.width / 2f
        val cy = previewView.height / 2f
        val px = cx + (x - cx) / extraScale
        val py = cy + (y - cy) / extraScale
        val point = previewView.meteringPointFactory.createPoint(px, py)
        val action = FocusMeteringAction.Builder(point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(5, TimeUnit.SECONDS)
            .build()
        try { cam.cameraControl.startFocusAndMetering(action) } catch (_: Exception) {}

        focusRing.x = x - focusRing.width / 2f
        focusRing.y = y - focusRing.height / 2f
        focusRing.alpha = 1f
        focusRing.scaleX = 1.3f; focusRing.scaleY = 1.3f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(800).setDuration(300).start()
        }.start()
    }

    // ---------- Pausa (foto a máxima resolución) ----------

    private fun pause() {
        val quick = previewView.bitmap
        if (quick == null) {
            Toast.makeText(this, "Espera a que salga la imagen", Toast.LENGTH_SHORT).show()
            return
        }
        paused = true
        val token = ++pauseToken
        frozenBase = camRatio
        frozenScale = extraScale
        panX = 0f; panY = 0f
        original = quick
        showBitmap(quick)
        frozenView.visibility = View.VISIBLE
        pauseTag.visibility = View.VISIBLE
        btnPause.text = "▶ Seguir"
        applyFrozen()

        // Foto de alta resolución para poder ampliar sin perder detalle
        val ic = imageCapture
        if (ic == null) { cameraProvider?.unbindAll(); return }
        ic.takePicture(ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val front = useFront
                    worker.execute {
                        val hi = try { toUprightBitmap(image, front) } catch (e: Throwable) { null }
                        image.close()
                        runOnUiThread {
                            if (paused && token == pauseToken && hi != null) {
                                original = hi
                                showBitmap(hi)
                                if (sharpLevel > 0) applySharpness()
                            }
                            if (paused && token == pauseToken) cameraProvider?.unbindAll()
                        }
                    }
                }
                override fun onError(e: ImageCaptureException) {
                    if (paused && token == pauseToken) cameraProvider?.unbindAll()
                }
            })
    }

    private fun toUprightBitmap(image: ImageProxy, front: Boolean): Bitmap {
        val bmp = image.toBitmap()
        val m = Matrix()
        m.postRotate(image.imageInfo.rotationDegrees.toFloat())
        if (front) m.postScale(-1f, 1f)
        val longSide = max(bmp.width, bmp.height)
        if (longSide > 4000) { val s = 4000f / longSide; m.postScale(s, s) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun resume() {
        paused = false
        pauseToken++
        sharpLevel = 0
        updateSharpButton()
        frozenView.visibility = View.GONE
        frozenView.setImageDrawable(null)
        original = null
        pauseTag.visibility = View.GONE
        btnPause.text = "⏸ Pausa"
        bindCamera()
    }

    private fun showBitmap(b: Bitmap) = frozenView.setImageBitmap(b)

    private fun setFrozenTotal(total: Float) {
        frozenScale = (total / frozenBase).coerceIn(1f, maxZoom / frozenBase)
        applyFrozen()
    }

    private fun applyFrozen() {
        val w = frozenView.width.toFloat()
        val h = frozenView.height.toFloat()
        val limX = (frozenScale - 1f) * w / 2f
        val limY = (frozenScale - 1f) * h / 2f
        panX = panX.coerceIn(-limX, limX)
        panY = panY.coerceIn(-limY, limY)
        frozenView.scaleX = frozenScale
        frozenView.scaleY = frozenScale
        frozenView.translationX = panX
        frozenView.translationY = panY
        updateZoomUi(frozenBase * frozenScale)
    }

    // ---------- Nitidez digital ----------

    private fun cycleSharpness() {
        if (!paused) {
            pause()
            if (!paused) return
        }
        sharpLevel = (sharpLevel + 1) % sharpAmounts.size
        updateSharpButton()
        applySharpness()
    }

    private fun updateSharpButton() {
        btnSharp.text = if (sharpLevel == 0) "✨ Nitidez" else "✨ Nitidez $sharpLevel"
    }

    private fun applySharpness() {
        val src = original ?: return
        val level = sharpLevel
        if (level == 0) { showBitmap(src); return }
        val token = pauseToken
        worker.execute {
            val out = try { sharpen(src, sharpAmounts[level]) } catch (e: Throwable) { null }
            runOnUiThread {
                if (out != null && paused && token == pauseToken &&
                    level == sharpLevel && src === original) showBitmap(out)
            }
        }
    }

    /** Máscara de enfoque 3x3: realza bordes y detalle. */
    private fun sharpen(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val inP = IntArray(w * h)
        src.getPixels(inP, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val r0 = (if (y > 0) y - 1 else 0) * w
            val r1 = y * w
            val r2 = (if (y < h - 1) y + 1 else h - 1) * w
            for (x in 0 until w) {
                val x0 = if (x > 0) x - 1 else 0
                val x1 = if (x < w - 1) x + 1 else w - 1
                var sr = 0; var sg = 0; var sb = 0
                var c: Int
                c = inP[r0 + x0]; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r0 + x];  sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r0 + x1]; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r1 + x0]; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r1 + x];  sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r1 + x1]; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r2 + x0]; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r2 + x];  sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r2 + x1]; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
                c = inP[r1 + x]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                val nr = (r + amount * (r - sr / 9f)).roundToInt().coerceIn(0, 255)
                val ng = (g + amount * (g - sg / 9f)).roundToInt().coerceIn(0, 255)
                val nb = (b + amount * (b - sb / 9f)).roundToInt().coerceIn(0, 255)
                out[r1 + x] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
            }
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }

    // ---------- Luz ----------

    private fun toggleLight() {
        lightOn = !lightOn
        lightPanel.visibility = if (lightOn) View.VISIBLE else View.GONE
        val lp = window.attributes
        lp.screenBrightness =
            if (lightOn) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        btnLight.text = if (lightOn) "💡 Apagar" else "💡 Luz"
        if (paused) frozenView.post { applyFrozen() }
    }
}
