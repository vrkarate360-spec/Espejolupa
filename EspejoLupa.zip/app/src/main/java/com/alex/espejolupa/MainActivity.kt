package com.alex.espejolupa

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var frozenView: ImageView
    private lateinit var effectLayer: FrameLayout
    private lateinit var lightPanel: View
    private lateinit var lightBottom: View
    private lateinit var controls: View
    private lateinit var cameraArea: FrameLayout
    private lateinit var touchLayer: View
    private lateinit var focusRing: View
    private lateinit var pauseTag: TextView
    private lateinit var zoomBar: SeekBar
    private lateinit var zoomText: TextView
    private lateinit var btnPause: Button
    private lateinit var btnLight: Button
    private lateinit var btnSharp: Button
    private lateinit var btnSwitch: Button

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val maxZoom = 20f          // zoom total: óptico/cámara + digital

    private var useFront = true
    private var lightOn = false
    private var lightColorIndex = 0
    private val lightColors = intArrayOf(
        Color.WHITE, Color.rgb(255, 236, 205), Color.rgb(228, 238, 255)
    )

    // Imagen en directo
    private var liveZoom = 1f          // zoom total pedido
    private var camRatio = 1f          // parte que hace la cámara
    private var extraScale = 1f        // parte digital (ampliar la vista)

    // Imagen en pausa
    private var paused = false
    private var pauseToken = 0
    private var frozenBase = 1f        // zoom de cámara cuando se pausó
    private var frozenScale = 1f       // ampliación digital sobre la foto
    private var panX = 0f
    private var panY = 0f
    private var original: Bitmap? = null
    private var sharpLevel = 0
    private val sharpRadius = floatArrayOf(0f, 1.5f, 2.5f, 3.5f, 5f)
    private val sharpAmounts = floatArrayOf(0f, 0.8f, 1.4f, 2.0f, 2.8f)
    private val ui = Handler(Looper.getMainLooper())

    // Último punto donde tocaste para enfocar (coordenadas de la vista sin ampliar)
    private var focusX = -1f
    private var focusY = -1f

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera()
            else Toast.makeText(this, "Hace falta permiso de cámara", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        frozenView = findViewById(R.id.frozenView)
        effectLayer = findViewById(R.id.effectLayer)
        lightPanel = findViewById(R.id.lightPanel)
        lightBottom = findViewById(R.id.lightBottom)
        controls = findViewById(R.id.controls)
        cameraArea = findViewById(R.id.cameraArea)
        touchLayer = findViewById(R.id.touchLayer)
        focusRing = findViewById(R.id.focusRing)
        pauseTag = findViewById(R.id.pauseTag)
        zoomBar = findViewById(R.id.zoomBar)
        zoomText = findViewById(R.id.zoomText)
        btnPause = findViewById(R.id.btnPause)
        btnLight = findViewById(R.id.btnLight)
        btnSharp = findViewById(R.id.btnSharp)
        btnSwitch = findViewById(R.id.btnSwitch)

        try {
            val v = packageManager.getPackageInfo(packageName, 0).versionName
            Toast.makeText(this, "EspejoLupa $v", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {}

        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE

        setupZoomBar()
        setupGestures()

        btnPause.setOnClickListener { if (paused) resume() else pause() }
        btnLight.setOnClickListener { toggleLight() }
        btnSharp.setOnClickListener { cycleSharpness() }
        btnSwitch.setOnClickListener {
            if (paused) resume()
            useFront = !useFront
            liveZoom = 1f
            focusX = -1f; focusY = -1f
            bindCamera()
        }
        lightPanel.setOnClickListener {
            lightColorIndex = (lightColorIndex + 1) % lightColors.size
            lightPanel.setBackgroundColor(lightColors[lightColorIndex])
            lightBottom.setBackgroundColor(lightColors[lightColorIndex])
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permLauncher.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        worker.shutdown()
    }

    // ---------- Cámara ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        var selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                       else CameraSelector.DEFAULT_BACK_CAMERA
        if (!provider.hasCamera(selector)) {
            useFront = !useFront
            selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                       else CameraSelector.DEFAULT_BACK_CAMERA
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()
        try {
            camera = provider.bindToLifecycle(this, selector, preview, imageCapture)
            val wanted = liveZoom
            camera?.cameraInfo?.zoomState?.observe(this) { z ->
                // Cuando la cámara está lista, aplicamos el zoom pedido una vez
                if (z != null) {
                    camera?.cameraInfo?.zoomState?.removeObservers(this)
                    setLiveZoom(wanted)
                }
            }
            setLiveZoom(wanted)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir la cámara", Toast.LENGTH_LONG).show()
        }
    }

    /** Reparte el zoom total entre la cámara (máxima calidad) y ampliación digital. */
    private fun setLiveZoom(z: Float) {
        liveZoom = z.coerceIn(1f, maxZoom)
        val st = camera?.cameraInfo?.zoomState?.value
        val camMax = st?.maxZoomRatio ?: 1f
        val camMin = max(1f, st?.minZoomRatio ?: 1f)
        camRatio = liveZoom.coerceIn(camMin, max(camMin, camMax))
        camera?.cameraControl?.setZoomRatio(camRatio)
        extraScale = liveZoom / camRatio
        previewView.scaleX = extraScale
        previewView.scaleY = extraScale
        updateZoomUi(liveZoom)
    }

    // ---------- Zoom (barra y pellizco) ----------

    private fun zoomToProgress(z: Float) = (ln(z) / ln(maxZoom) * 100).roundToInt()
    private fun progressToZoom(p: Int) = maxZoom.pow(p / 100f)

    private fun updateZoomUi(total: Float) {
        zoomText.text = if (total < 10f) String.format("%.1fx", total)
                        else "${total.roundToInt()}x"
        zoomBar.progress = zoomToProgress(total)
    }

    private fun setupZoomBar() {
        zoomBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val z = progressToZoom(progress)
                if (paused) setFrozenTotal(z) else setLiveZoom(z)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: ScaleGestureDetector): Boolean {
                    if (paused) setFrozenTotal(frozenBase * frozenScale * d.scaleFactor)
                    else setLiveZoom(liveZoom * d.scaleFactor)
                    return true
                }
            })
        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (!paused) focusAt(e.x, e.y)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (paused && !scaleDetector.isInProgress) {
                    panX -= dx; panY -= dy
                    applyFrozen()
                }
                return true
            }
        })
        touchLayer.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(ev)
            true
        }
    }

    // ---------- Enfoque (tocar la pantalla) ----------

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        // Pasar el punto tocado a coordenadas de la vista sin la ampliación digital
        val cx = previewView.width / 2f
        val cy = previewView.height / 2f
        val px = cx + (x - cx) / extraScale
        val py = cy + (y - cy) / extraScale
        focusX = px; focusY = py
        val point = previewView.meteringPointFactory.createPoint(px, py)
        val action = FocusMeteringAction.Builder(point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(5, TimeUnit.SECONDS)
            .build()
        try { cam.cameraControl.startFocusAndMetering(action) } catch (_: Exception) {}

        focusRing.x = x - focusRing.width / 2f
        focusRing.y = y - focusRing.height / 2f
        focusRing.alpha = 1f
        focusRing.scaleX = 1.3f; focusRing.scaleY = 1.3f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(800).setDuration(300).start()
        }.start()
    }

    // ---------- Pausa (foto a máxima resolución) ----------

    private fun pause() {
        val quick = previewView.bitmap
        if (quick == null) {
            Toast.makeText(this, "Espera a que salga la imagen", Toast.LENGTH_SHORT).show()
            return
        }
        paused = true
        val token = ++pauseToken
        frozenBase = camRatio
        frozenScale = extraScale
        panX = 0f; panY = 0f
        original = quick
        showBitmap(quick)
        frozenView.visibility = View.VISIBLE
        pauseTag.visibility = View.VISIBLE
        btnPause.text = "▶ Seguir"
        applyFrozen()

        // Primero enfoca (donde tocaste o en el centro) y luego hace la foto
        // de alta resolución para poder ampliar sin perder detalle
        val cam = camera
        if (cam == null || imageCapture == null) { cameraProvider?.unbindAll(); return }
        var shot = false
        val shoot = Runnable {
            if (!shot && paused && token == pauseToken) { shot = true; captureHiRes(token) }
        }
        try {
            val px = if (focusX >= 0) focusX else previewView.width / 2f
            val py = if (focusY >= 0) focusY else previewView.height / 2f
            val point = previewView.meteringPointFactory.createPoint(px, py)
            val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF)
                .disableAutoCancel().build()
            val fut = cam.cameraControl.startFocusAndMetering(action)
            fut.addListener(shoot, ContextCompat.getMainExecutor(this))
        } catch (_: Exception) {
            shoot.run()
        }
        ui.postDelayed(shoot, 1500)   // por si la cámara no tiene autoenfoque
    }

    private fun captureHiRes(token: Int) {
        val ic = imageCapture ?: run { cameraProvider?.unbindAll(); return }
        ic.takePicture(ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val front = useFront
                    worker.execute {
                        val hi = try { toUprightBitmap(image, front) } catch (e: Throwable) { null }
                        image.close()
                        runOnUiThread {
                            if (paused && token == pauseToken && hi != null) {
                                original = hi
                                showBitmap(hi)
                            }
                            if (paused && token == pauseToken) cameraProvider?.unbindAll()
                        }
                    }
                }
                override fun onError(e: ImageCaptureException) {
                    if (paused && token == pauseToken) cameraProvider?.unbindAll()
                }
            })
    }

    private fun toUprightBitmap(image: ImageProxy, front: Boolean): Bitmap {
        val bmp = image.toBitmap()
        val m = Matrix()
        m.postRotate(image.imageInfo.rotationDegrees.toFloat())
        if (front) m.postScale(-1f, 1f)
        val longSide = max(bmp.width, bmp.height)
        if (longSide > 4000) { val s = 4000f / longSide; m.postScale(s, s) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun resume() {
        paused = false
        pauseToken++
        frozenView.visibility = View.GONE
        frozenView.setImageDrawable(null)
        original = null
        pauseTag.visibility = View.GONE
        btnPause.text = "⏸ Pausa"
        bindCamera()
    }

    private fun showBitmap(b: Bitmap) = frozenView.setImageBitmap(b)

    private fun setFrozenTotal(total: Float) {
        frozenScale = (total / frozenBase).coerceIn(1f, maxZoom / frozenBase)
        applyFrozen()
    }

    private fun applyFrozen() {
        val w = frozenView.width.toFloat()
        val h = frozenView.height.toFloat()
        val limX = (frozenScale - 1f) * w / 2f
        val limY = (frozenScale - 1f) * h / 2f
        panX = panX.coerceIn(-limX, limX)
        panY = panY.coerceIn(-limY, limY)
        frozenView.scaleX = frozenScale
        frozenView.scaleY = frozenScale
        frozenView.translationX = panX
        frozenView.translationY = panY
        updateZoomUi(frozenBase * frozenScale)
    }

    // ---------- Nitidez digital ----------

    private fun cycleSharpness() {
        if (Build.VERSION.SDK_INT < 33) {
            Toast.makeText(this, "La nitidez en directo necesita Android 13 o superior",
                Toast.LENGTH_LONG).show()
            return
        }
        sharpLevel = (sharpLevel + 1) % sharpAmounts.size
        updateSharpButton()
        applySharpEffect()
    }

    private fun updateSharpButton() {
        btnSharp.text = if (sharpLevel == 0) "✨ Nitidez" else "✨ Nitidez $sharpLevel"
    }

    /** Nitidez en tiempo real con la gráfica del móvil (Android 13+). */
    private fun applySharpEffect() {
        if (Build.VERSION.SDK_INT < 33) return
        if (sharpLevel == 0) {
            effectLayer.setRenderEffect(null)
            return
        }
        val shader = RuntimeShader(SHARPEN_AGSL)
        shader.setFloatUniform("radius", sharpRadius[sharpLevel] * resources.displayMetrics.density / 2.5f)
        shader.setFloatUniform("amount", sharpAmounts[sharpLevel])
        effectLayer.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "content"))
    }

    companion object {
        // Máscara de enfoque: imagen + fuerza x (imagen - imagen desenfocada)
        private const val SHARPEN_AGSL = """
            uniform shader content;
            uniform float radius;
            uniform float amount;
            half4 main(float2 p) {
                float4 c = float4(content.eval(p));
                float2 dx = float2(radius, 0.0);
                float2 dy = float2(0.0, radius);
                float3 s = float3(content.eval(p + dx).rgb) + float3(content.eval(p - dx).rgb)
                         + float3(content.eval(p + dy).rgb) + float3(content.eval(p - dy).rgb);
                float3 d = float3(content.eval(p + dx + dy).rgb) + float3(content.eval(p - dx - dy).rgb)
                         + float3(content.eval(p + dx - dy).rgb) + float3(content.eval(p - dx + dy).rgb);
                float3 blur = (c.rgb * 4.0 + s * 2.0 + d) / 16.0;
                float3 r = clamp(c.rgb + amount * (c.rgb - blur), 0.0, 1.0);
                return half4(half3(r), half(c.a));
            }
        """
    }

    // ---------- Luz ----------

    private fun toggleLight() {
        lightOn = !lightOn
        if (lightOn) {
            // Franja blanca detrás de los botones, del mismo alto que los controles
            lightBottom.layoutParams = lightBottom.layoutParams.apply { height = controls.height }
            lightBottom.setBackgroundColor(lightColors[lightColorIndex])
            lightPanel.setBackgroundColor(lightColors[lightColorIndex])
            controls.setBackgroundColor(Color.TRANSPARENT)
            zoomText.setTextColor(Color.rgb(60, 60, 60))
        } else {
            controls.setBackgroundColor(Color.parseColor("#88000000"))
            zoomText.setTextColor(Color.WHITE)
        }
        lightPanel.visibility = if (lightOn) View.VISIBLE else View.GONE
        lightBottom.visibility = if (lightOn) View.VISIBLE else View.GONE
        val lp = window.attributes
        lp.screenBrightness =
            if (lightOn) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        btnLight.text = if (lightOn) "💡 Apagar" else "💡 Luz"
        if (paused) frozenView.postDelayed({ applyFrozen() }, 50)
    }
}
