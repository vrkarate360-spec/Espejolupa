package com.alex.espejolupa

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var frozenView: ImageView
    private lateinit var lightPanel: View
    private lateinit var cameraArea: FrameLayout
    private lateinit var zoomBar: SeekBar
    private lateinit var zoomText: TextView
    private lateinit var btnPause: Button
    private lateinit var btnLight: Button
    private lateinit var btnSwitch: Button

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null

    private var useFront = true      // empieza como espejo (cámara de la pantalla)
    private var paused = false
    private var lightOn = false
    private var frozenScale = 1f
    private val maxFrozenScale = 8f

    // Tonos de luz: blanca, cálida, fría (toca el panel para cambiar)
    private val lightColors = intArrayOf(
        Color.WHITE,
        Color.rgb(255, 236, 205),
        Color.rgb(228, 238, 255)
    )
    private var lightColorIndex = 0

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera()
            else Toast.makeText(this, "Hace falta permiso de cámara", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        frozenView = findViewById(R.id.frozenView)
        lightPanel = findViewById(R.id.lightPanel)
        cameraArea = findViewById(R.id.cameraArea)
        zoomBar = findViewById(R.id.zoomBar)
        zoomText = findViewById(R.id.zoomText)
        btnPause = findViewById(R.id.btnPause)
        btnLight = findViewById(R.id.btnLight)
        btnSwitch = findViewById(R.id.btnSwitch)

        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER

        setupZoomBar()
        setupPinch()

        btnPause.setOnClickListener { togglePause() }
        btnLight.setOnClickListener { toggleLight() }
        btnSwitch.setOnClickListener {
            if (paused) togglePause()
            useFront = !useFront
            bindCamera()
        }
        lightPanel.setOnClickListener {
            lightColorIndex = (lightColorIndex + 1) % lightColors.size
            lightPanel.setBackgroundColor(lightColors[lightColorIndex])
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        camera?.cameraInfo?.zoomState?.removeObservers(this)
        provider.unbindAll()

        var selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                       else CameraSelector.DEFAULT_BACK_CAMERA
        if (!provider.hasCamera(selector)) {
            useFront = !useFront
            selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                       else CameraSelector.DEFAULT_BACK_CAMERA
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }
        try {
            camera = provider.bindToLifecycle(this, selector, preview)
            camera?.cameraInfo?.zoomState?.observe(this) { z ->
                if (!paused) {
                    zoomBar.progress = (z.linearZoom * 100).roundToInt()
                    zoomText.text = String.format("%.1fx", z.zoomRatio)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir la cámara", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupZoomBar() {
        zoomBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (paused) {
                    frozenScale = 1f + (maxFrozenScale - 1f) * progress / 100f
                    applyFrozenScale()
                } else {
                    camera?.cameraControl?.setLinearZoom(progress / 100f)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupPinch() {
        val detector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: ScaleGestureDetector): Boolean {
                    if (paused) {
                        frozenScale = (frozenScale * d.scaleFactor).coerceIn(1f, maxFrozenScale)
                        applyFrozenScale()
                        zoomBar.progress =
                            ((frozenScale - 1f) / (maxFrozenScale - 1f) * 100).roundToInt()
                    } else {
                        val z = camera?.cameraInfo?.zoomState?.value ?: return true
                        val ratio = (z.zoomRatio * d.scaleFactor)
                            .coerceIn(z.minZoomRatio, z.maxZoomRatio)
                        camera?.cameraControl?.setZoomRatio(ratio)
                    }
                    return true
                }
            })
        val touch = View.OnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            ev.action == MotionEvent.ACTION_DOWN || detector.isInProgress
        }
        previewView.setOnTouchListener(touch)
        frozenView.setOnTouchListener(touch)
    }

    private fun applyFrozenScale() {
        frozenView.scaleX = frozenScale
        frozenView.scaleY = frozenScale
        zoomText.text = String.format("%.1fx", frozenScale)
    }

    private fun togglePause() {
        if (!paused) {
            val bmp = previewView.bitmap
            if (bmp == null) {
                Toast.makeText(this, "Espera a que salga la imagen", Toast.LENGTH_SHORT).show()
                return
            }
            paused = true
            frozenView.setImageBitmap(bmp)
            frozenScale = 1f
            applyFrozenScale()
            zoomBar.progress = 0
            frozenView.visibility = View.VISIBLE
            camera?.cameraInfo?.zoomState?.removeObservers(this)
            cameraProvider?.unbindAll()   // ahorra batería mientras está en pausa
            btnPause.text = "▶ Seguir"
        } else {
            paused = false
            frozenView.visibility = View.GONE
            frozenView.setImageDrawable(null)
            btnPause.text = "⏸ Pausa"
            bindCamera()
        }
    }

    private fun toggleLight() {
        lightOn = !lightOn
        lightPanel.visibility = if (lightOn) View.VISIBLE else View.GONE
        val lp = window.attributes
        lp.screenBrightness =
            if (lightOn) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        btnLight.text = if (lightOn) "💡 Apagar" else "💡 Luz"
    }
}
